Tanim's Stupid Intro
====================
:author: Tanim Islam
:title: Tanim's Stupid Blog
:layout: page
:date: 2020-12-25 12:00:00
:slug: landing-page-about-hidden
:status: hidden
       
I exist. I am a professional seat-filler. I have a presence in several places online, and I have a home page `here <https://tanimislam.github.io>`_. BORING!

This blog, which uses Pelican_ for static site generation, and the Elegant_ theme, started off as a conversion of my older Wordpress blog: https://tanimislamblog.wordpress.com. I am transitioning off the old blg in order to document ``code`` and mathematical formulae (just look at `my philosophy on driving`_). I also hope to have some "fixed" blog articles (on the media on my Plex_ server, on the progression of COVID-19 in the United States, etc.) that summarizes *changing* information.

Airing of grievances part
---------------------------
I have a hate-gasm against people and organizations that describe how well they have documented their tool. The Elegant_ theme is no exception! I started off from `this blog post on creating a home page with the Elegant theme <https://elegant.oncrashreboot.com/write-about-me>`_, which was necessary but not sufficient.

* First party foul: Description on how to do this in Markdown_ only. There was no mention of how to do this in ReStructuredText_.

* Second party foul: If you put in a ``:status: hidden`` (remember, ReStructuredText_!), ``pelican`` emits a helpful vomit burp,

  .. code-block:: console

     ERROR: Unknown status 'hidden' for file ..., skipping it.

  Resolution: remove that part.

Easiest to show rather than tell how to get this working. Put these formatting blog parts into your blog-post-which-is-actually-your-home-page.

.. code-block:: rst

   :author: Tanim Islam
   :title: Tanim's Stupid Blog
   :layout: page
   :date: 2020-12-25 12:00:00
   :slug: landing-page-about-hidden

The ``:slug:`` *has* to be ``landing-page-about-hidden``.
	  

.. _Pelican: https://blog.getpelican.com
.. _Elegant: https://elegant.oncrashreboot.com
.. _Plex: https://plex.tv
.. _Markdown: https://daringfireball.net/projects/markdown/
.. _ReStructuredText: https://docutils.sourceforge.io/rst.html
.. _`my philosophy on driving`: my-philosophy-on-driving.html
