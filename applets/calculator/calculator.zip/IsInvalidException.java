public class IsInvalidException extends Exception {
    public IsInvalidException() { super();}
}
